# Import necessary to preserve backward compatibility of pickles

from joblib.numpy_pickle import *
